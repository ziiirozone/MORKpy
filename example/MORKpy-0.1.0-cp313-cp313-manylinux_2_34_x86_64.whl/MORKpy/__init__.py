from .MORKpy import *

__doc__ = MORKpy.__doc__
if hasattr(MORKpy, "__all__"):
    __all__ = MORKpy.__all__